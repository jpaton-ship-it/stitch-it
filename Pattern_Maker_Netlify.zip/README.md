# Pattern Maker

Paste a link to a piece of clothing and get a printable, full-size sewing pattern.

- `public/index.html` is the whole website (pattern drafting and PDF making run in the browser).
- `netlify/functions/read-link.mjs` is a small server function. It opens the product page, finds the size guide, and asks Claude (Anthropic's AI) to work out the garment, style, fabric and sizes.
- `netlify.toml` tells Netlify where everything is.

## Set it up (about 15 minutes, free apart from AI use)

You need three free accounts: GitHub, Netlify and the Anthropic Console. A computer makes this much easier than a phone.

### 1. Get an Anthropic API key
1. Go to https://console.anthropic.com and sign up.
2. Add a small amount of credit under Billing (US$5 lasts a long time).
3. Under Billing or Limits, set a monthly spend limit (for example US$10) so costs can never run away.
4. Go to API Keys, create a key, and copy it somewhere safe. It starts with `sk-ant-`.

### 2. Put the files on GitHub
1. Go to https://github.com and sign up or log in.
2. Click **New repository**. Name it `pattern-maker`, choose **Private**, and click **Create repository**.
3. Click **uploading an existing file**.
4. Unzip `Pattern_Maker_Netlify.zip` on your computer. Drag everything inside the unzipped folder (the `public` folder, the `netlify` folder, `netlify.toml` and this README) onto the GitHub page.
5. Click **Commit changes**.

Check that the repository shows `public`, `netlify` and `netlify.toml` at the top level, and that `netlify/functions/read-link.mjs` is there.

### 3. Connect it to Netlify
1. Go to https://app.netlify.com and sign up with your GitHub account.
2. Click **Add new project**, then **Import an existing project**, then **GitHub**, and pick `pattern-maker`.
3. Leave the build settings as they are (Netlify reads them from `netlify.toml`). Click **Deploy**.
4. When it finishes, open **Project configuration**, then **Environment variables**, then **Add a variable**:
   - Key: `ANTHROPIC_API_KEY`, Value: your `sk-ant-...` key.
   - Recommended: Key: `SITE_CODE`, Value: any word, e.g. `linen`. People need this code to read links, so strangers can't use up your AI credit. Share the code with your mother-in-law.
5. Open **Deploys** and click **Trigger deploy**, then **Deploy project**, so the new settings take effect.
6. Optional: under **Domain management** or **Project configuration**, change the site name to something nicer, e.g. `mums-pattern-maker.netlify.app`.

### 4. Try it
Open your site, paste a product link, enter the access code if asked, and click **Make my pattern**.

## Costs
Each link read is one AI request, usually a few cents. Netlify and GitHub are free at this level of use. Check current prices at https://www.anthropic.com/pricing.

## If something goes wrong
- "The site owner has not added an ANTHROPIC_API_KEY": add the variable (step 3.4), then redeploy (step 3.5).
- "That shop blocks automatic reading": some shops block robots. Use **Choose a garment yourself** and the shop's size guide.
- "The AI service returned an error": usually no credit left or a mistyped key. Check the Anthropic Console.
- Changing the AI model: add a variable `ANTHROPIC_MODEL` with another model name from the Anthropic docs.

## Sharing a ready-made link
You can send a link that starts reading straight away:
`https://YOUR-SITE.netlify.app/?link=https://shop.com/products/the-item`
