// Reads a clothing product page and asks Claude to turn it into a pattern plan.
// Needs the environment variable ANTHROPIC_API_KEY. Optional: SITE_CODE (access code), ANTHROPIC_MODEL.

const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";
const UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

function safeUrl(raw) {
  let u;
  try { u = new URL(String(raw || "").trim()); } catch { return null; }
  if (!/^https?:$/.test(u.protocol)) return null;
  const h = u.hostname.toLowerCase();
  if (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || !h.includes(".")) return null;
  if (/^\d+\.\d+\.\d+\.\d+$/.test(h) || h.includes(":")) return null; // no raw IP addresses
  return u;
}

async function getText(url, limitBytes = 2_500_000, ms = 12000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const r = await fetch(url, {
      redirect: "follow", signal: ctrl.signal,
      headers: { "user-agent": UA, accept: "text/html,application/json;q=0.9,*/*;q=0.8", "accept-language": "en-AU,en;q=0.9" }
    });
    if (!r.ok) return { ok: false, status: r.status, text: "" };
    const buf = await r.arrayBuffer();
    return { ok: true, status: r.status, text: new TextDecoder().decode(buf.slice(0, limitBytes)), finalUrl: r.url };
  } catch (e) {
    return { ok: false, status: 0, text: "", error: String(e && e.message || e) };
  } finally { clearTimeout(t); }
}

const decode = s => s.replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&#x27;/g, "'")
  .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n));

function meta(html, prop) {
  const re = new RegExp(`<meta[^>]+(?:property|name)=["']${prop}["'][^>]*>`, "i");
  const tag = html.match(re);
  if (!tag) return "";
  const c = tag[0].match(/content=["']([^"']*)["']/i);
  return c ? decode(c[1]).trim() : "";
}

function visibleText(html) {
  let s = html
    .replace(/<script\b(?![^>]*application\/ld\+json)[\s\S]*?<\/script>/gi, " ")
    .replace(/<(style|svg|noscript|iframe|template)\b[\s\S]*?<\/\1>/gi, " ")
    .replace(/<(br|\/p|\/div|\/li|\/tr|\/h\d|\/td|\/th)\b[^>]*>/gi, m => (/td|th/i.test(m) ? " | " : "\n"))
    .replace(/<[^>]+>/g, " ");
  s = decode(s).replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
  return s;
}

function jsonLd(html) {
  const out = [];
  const re = /<script[^>]+application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = re.exec(html))) out.push(m[1].trim().slice(0, 6000));
  return out.join("\n").slice(0, 12000);
}

function sizeGuideLinks(html, base) {
  const links = [];
  const re = /<a\b[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html))) {
    const text = m[2].replace(/<[^>]+>/g, " ");
    if (/size[\s_-]*(guide|chart|help)|fit[\s_-]*guide/i.test(m[1] + " " + text)) {
      try {
        const u = new URL(decode(m[1]), base);
        if (u.hostname === base.hostname && !links.includes(u.href)) links.push(u.href);
      } catch {}
    }
  }
  return links.slice(0, 2);
}

const TOOL = {
  name: "pattern_plan",
  description: "Return the sewing pattern plan for the product page.",
  input_schema: {
    type: "object",
    required: ["is_clothing", "product_name", "garment", "match", "match_note", "audience", "options", "fabric", "size_chart"],
    properties: {
      is_clothing: { type: "boolean", description: "False if the page is not a single clothing product (e.g. a category page, shoes, bag, jewellery)." },
      product_name: { type: "string" },
      brand: { type: "string" },
      garment: { type: "string", enum: ["shorts", "pants", "tee", "dress", "skirt"], description: "Closest shape the pattern library can make." },
      match: { type: "string", enum: ["exact", "close", "approximate"], description: "exact: same construction. close: same shape, small details missing. approximate: only the general shape matches." },
      match_note: { type: "string", description: "One or two plain sentences telling the sewer what the pattern will and will not reproduce (e.g. no buttons, no collar, no zip). Plain English, no dashes." },
      audience: { type: "string", enum: ["men", "women", "unisex"] },
      options: {
        type: "object",
        description: "Only the options that apply to the chosen garment.",
        properties: {
          fit: { type: "string", enum: ["slim", "regular", "relaxed"], description: "All garments. For tee and dress, relaxed means boxy with dropped shoulders. For skirt it is hip ease." },
          inseam: { type: "number", description: "shorts and pants: inside leg length in cm. Convert inches x 2.54. Shorts usually 8 to 23 cm." },
          leg: { type: "string", enum: ["relaxed", "straight", "tapered"], description: "pants only: relaxed means wide leg." },
          pockets: { type: "boolean", description: "shorts, pants, skirt: side seam pockets." },
          drawcord: { type: "boolean", description: "shorts and pants." },
          sleeve: { type: "string", enum: ["none", "short", "elbow", "long"], description: "tee and dress. Tee cannot be none." },
          neck: { type: "string", enum: ["crew", "scoop"], description: "tee and dress. V necks and collars map to scoop." },
          length: { type: "number", description: "tee and dress: length from the high shoulder point in cm. skirt: length below the waistband in cm. Omit if unknown." },
          flare: { type: "number", description: "dress only: extra width at the hem on each side seam in cm, 0 to 25. Bodycon 0, straight 2, A line 6 to 10, full 15+." },
          style: { type: "string", enum: ["straight", "aline", "full"], description: "skirt only." }
        }
      },
      fabric: {
        type: "object", required: ["recommendation"],
        properties: {
          composition: { type: "string", description: "Fabric composition as listed on the page, if any." },
          recommendation: { type: "string", description: "What fabric to buy to make this at home, 1 to 2 sentences, including weight in gsm if you can." }
        }
      },
      size_chart: {
        type: "object",
        description: "BODY measurements in cm for each size, from the page or its size guide. Use the midpoint of ranges. If the guide only gives garment measurements, estimate body measurements by subtracting typical ease and set source to 'estimated from garment measurements'. If no size guide is available, use a typical chart for this brand's market and set source to 'typical chart, not from the shop'.",
        required: ["source", "sizes"],
        properties: {
          source: { type: "string" },
          sizes: {
            type: "array",
            items: {
              type: "object", required: ["name"],
              properties: { name: { type: "string" }, chest: { type: "number" }, waist: { type: "number" }, hip: { type: "number" } }
            }
          },
          default_size: { type: "string", description: "A middle size to preselect." },
          height: { type: "number", description: "Typical wearer height in cm (model height if stated, else 178 men / 165 women)." }
        }
      }
    }
  }
};

const SYSTEM = `You help a home sewer recreate clothing they found online. You get text scraped from a product page (and maybe its size guide).
A pattern library can draft only these shapes:
- shorts: pull-on shorts, elastic waist, optional drawcord and side pockets
- pants: pull-on trousers, elastic waist, wide, straight or tapered leg
- tee: knit T-shirt with neckband, fitted, regular or boxy, short, elbow or long sleeves
- dress: knit T-shirt dress, optional sleeves, flared hem
- skirt: pull-on elastic waist skirt, straight, A-line or full
Pick the closest shape. Shirts and blouses map to tee, woven dresses to dress, zip or button-waist shorts and trousers to shorts or pants. Be honest in match_note about what will differ.
Use only facts from the page for details like inseam, length, composition and size guide numbers. Convert inches to cm. Call the pattern_plan tool exactly once.`;

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Use POST." }, 405);
  let body;
  try { body = await req.json(); } catch { return json({ error: "Bad request." }, 400); }

  const code = process.env.SITE_CODE;
  if (code && String(body.code || "").trim() !== code) return json({ error: "Enter the access code to read links.", needCode: true }, 401);
  if (!process.env.ANTHROPIC_API_KEY) return json({ error: "The site owner has not added an ANTHROPIC_API_KEY in Netlify yet." }, 500);

  const url = safeUrl(body.url);
  if (!url) return json({ error: "That doesn't look like a web link. Copy the full address starting with https://" }, 400);

  const page = await getText(url.href);
  if (!page.ok || page.text.length < 200) {
    return json({ error: page.status === 403 || page.status === 429
      ? "That shop blocks automatic reading. Choose the garment yourself below, or try a link from another shop."
      : "Couldn't open that page (" + (page.status || page.error || "no response") + "). Check the link, or choose the garment yourself below." }, 502);
  }
  const html = page.text;
  const base = new URL(page.finalUrl || url.href);
  const product = {
    url: base.href,
    title: meta(html, "og:title") || (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [, ""])[1].trim(),
    image: meta(html, "og:image") || meta(html, "twitter:image"),
    site: meta(html, "og:site_name") || base.hostname.replace(/^www\./, "")
  };
  if (product.image && product.image.startsWith("//")) product.image = "https:" + product.image;

  const parts = [];
  parts.push("URL: " + base.href);
  parts.push("TITLE: " + product.title);
  parts.push("DESCRIPTION: " + (meta(html, "og:description") || meta(html, "description")));
  const ld = jsonLd(html);
  if (ld) parts.push("STRUCTURED DATA:\n" + ld);

  // Shopify stores expose product data as JSON
  if (/\/products\/[^/]+/.test(base.pathname)) {
    const p = await getText(base.origin + base.pathname.replace(/\/$/, "") + ".js", 600000, 8000);
    if (p.ok && p.text.trim().startsWith("{")) {
      try {
        const j = JSON.parse(p.text);
        parts.push("SHOP PRODUCT DATA: " + JSON.stringify({
          title: j.title, type: j.type, tags: j.tags, options: j.options,
          description: visibleText(j.description || "").slice(0, 8000)
        }));
      } catch {}
    }
  }
  parts.push("PAGE TEXT:\n" + visibleText(html).slice(0, 24000));

  for (const link of sizeGuideLinks(html, base)) {
    const g = await getText(link, 1_500_000, 8000);
    if (g.ok) { parts.push("SIZE GUIDE PAGE (" + link + "):\n" + visibleText(g.text).slice(0, 10000)); break; }
  }

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 45000);
  let ai;
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", signal: ctrl.signal,
      headers: {
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL, max_tokens: 2500, system: SYSTEM,
        tools: [TOOL], tool_choice: { type: "tool", name: TOOL.name },
        messages: [{ role: "user", content: parts.join("\n\n").slice(0, 60000) }]
      })
    });
    ai = await r.json();
    if (!r.ok) {
      const msg = ai && ai.error && ai.error.message || ("status " + r.status);
      return json({ error: "The AI service returned an error: " + msg }, 502);
    }
  } catch (e) {
    return json({ error: "The AI took too long to answer. Try again in a moment." }, 504);
  } finally { clearTimeout(timer); }

  const call = (ai.content || []).find(c => c.type === "tool_use");
  if (!call) return json({ error: "The AI couldn't work out a pattern from that page. Choose the garment yourself below." }, 502);
  const plan = call.input;
  if (plan.is_clothing === false) return json({ error: "That page doesn't look like a single clothing item. Try the link to one product.", product }, 422);
  return json({ product, plan, usage: ai.usage });
};

export const config = { path: "/api/read-link" };
